module projectjava {
	requires java.desktop;
	requires java.sql;
}